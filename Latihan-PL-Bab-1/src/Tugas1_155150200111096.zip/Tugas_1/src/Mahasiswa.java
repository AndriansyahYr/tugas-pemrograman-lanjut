import java.util.Scanner;
public class Mahasiswa {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Masukkan jumlah mahasiswa yang mengerjakan :  ");
        int count = input.nextInt();
        Index [] mahasiswa = new Index[count];
        for (int i=0;i<mahasiswa.length;i++){;
            mahasiswa[i] = new Index();
            System.out.print("Masukan nama mahasiswa ke "+(i+1)+"     :  ");
            String nama = input.next();
            System.out.print("Masukan nim                     :  ");
            String nim = input.next();
            System.out.print("Masukan jumlah kata per halaman :  ");
            int kata = input.nextInt();
            mahasiswa[i].data(nama, nim, kata);
            System.out.println("");
        }
        for (int i=0;i<mahasiswa.length;i++){
            mahasiswa[i].Display();
        
        }
    }
   
}
