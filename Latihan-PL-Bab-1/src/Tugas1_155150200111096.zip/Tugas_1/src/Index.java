public class Index {
    int kata, halaman=30, jumlah;
    String nama, nim;
    public void data(String nama, String nim, int kata){
        this.nama = nama;
        this.nim = nim;
        this.kata = kata;
        this.jumlah = kata*halaman;
    }
    public void Display(){
        System.out.println("");
        System.out.println("Nama mahasiswa          : "+nama);
        System.out.println("Nim                     : "+nim);
        System.out.println("Jumlah kata per halaman : "+kata);
        System.out.println("Jumlah halaman          : "+halaman);
        System.out.println("Total semua kata        : "+jumlah);
    }
}