
package nama;

public class Nama {


    public static void main(String[] args) {
     int nilai=10;
     double nilai_2=5.3;
     int hasil;
     
     int nilai_3= 100;
String s = "Belajar Java";
System.out.println(nilai+nilai_2);
System.out.println("Kita sedang "+s);
        System.out.println(nilai_3/(nilai-nilai_2));
         
                
    }
    
}
